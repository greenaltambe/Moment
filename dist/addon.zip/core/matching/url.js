/**
 * Moment Core: Canonical URL Model & Normalization
 * Pure domain model - zero browser dependencies.
 * Uses WHATWG URL parsing with strict canonicalization.
 */
/**
 * Parses and canonicalizes a raw URL string for policy evaluation.
 *
 * Rules:
 * - Only standard 'http:' and 'https:' protocols are permitted.
 * - Hostnames are normalized to lowercase.
 * - Subdomains ('www.', 'm.', 'mobile.') are strictly preserved.
 * - Default ports (80 for HTTP, 443 for HTTPS) are normalized to empty string.
 * - Explicit non-default ports (e.g. 8080) are preserved.
 * - Returns null for invalid URLs or non-web schemes (never throws).
 */
export function parseCanonicalUrl(rawUrl) {
    if (!rawUrl || typeof rawUrl !== 'string') {
        return null;
    }
    let parsed;
    try {
        parsed = new URL(rawUrl.trim());
    }
    catch {
        return null;
    }
    // Enforce permitted protocols
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        return null;
    }
    const protocol = parsed.protocol;
    const hostname = parsed.hostname.toLowerCase();
    // Normalize default ports
    let port = parsed.port;
    if ((protocol === 'http:' && port === '80') || (protocol === 'https:' && port === '443')) {
        port = '';
    }
    // Path normalization
    let pathname = parsed.pathname || '/';
    if (!pathname.startsWith('/')) {
        pathname = '/' + pathname;
    }
    const pathSegments = pathname
        .split('/')
        .filter((seg) => seg.length > 0);
    // Parse search parameters into an immutable map
    const searchParams = new Map();
    parsed.searchParams.forEach((val, key) => {
        searchParams.set(key, val);
    });
    return {
        raw: rawUrl,
        protocol,
        hostname,
        port,
        pathname,
        pathSegments,
        search: parsed.search,
        searchParams,
        hash: parsed.hash,
    };
}
/**
 * Reconstructs a canonical string representation from a CanonicalUrl.
 */
export function toCanonicalString(url, includeQuery = true) {
    const portPart = url.port ? `:${url.port}` : '';
    const base = `${url.protocol}//${url.hostname}${portPart}${url.pathname}`;
    if (includeQuery && url.search) {
        return base + url.search;
    }
    return base;
}
